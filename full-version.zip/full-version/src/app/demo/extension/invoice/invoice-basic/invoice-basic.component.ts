import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invoice-basic',
  templateUrl: './invoice-basic.component.html',
  styleUrls: ['./invoice-basic.component.scss']
})
export class InvoiceBasicComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
