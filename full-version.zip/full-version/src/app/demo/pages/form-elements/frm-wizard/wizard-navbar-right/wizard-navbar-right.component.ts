import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wizard-navbar-right',
  templateUrl: './wizard-navbar-right.component.html',
  styleUrls: ['./wizard-navbar-right.component.scss']
})
export class WizardNavbarRightComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
