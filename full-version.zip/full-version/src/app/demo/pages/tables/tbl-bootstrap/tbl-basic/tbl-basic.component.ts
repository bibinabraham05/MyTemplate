import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tbl-basic',
  templateUrl: './tbl-basic.component.html',
  styleUrls: ['./tbl-basic.component.scss']
})
export class TblBasicComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
