import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CoreChartRoutingModule } from './core-chart-routing.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CoreChartRoutingModule
  ]
})
export class CoreChartModule { }
