import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-auth-change-password',
  templateUrl: './auth-change-password.component.html',
  styleUrls: ['./auth-change-password.component.scss']
})
export class AuthChangePasswordComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
