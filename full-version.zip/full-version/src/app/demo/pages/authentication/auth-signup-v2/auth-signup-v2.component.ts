import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-auth-signup-v2',
  templateUrl: './auth-signup-v2.component.html',
  styleUrls: ['./auth-signup-v2.component.scss']
})
export class AuthSignupV2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
