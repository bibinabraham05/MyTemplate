import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mainten-offline-ui',
  templateUrl: './mainten-offline-ui.component.html',
  styleUrls: ['./mainten-offline-ui.component.scss']
})
export class MaintenOfflineUiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
