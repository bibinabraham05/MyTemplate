import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-theme-horizontal-l2',
  templateUrl: './theme-horizontal-l2.component.html',
  styleUrls: ['./theme-horizontal-l2.component.scss']
})
export class ThemeHorizontalL2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
