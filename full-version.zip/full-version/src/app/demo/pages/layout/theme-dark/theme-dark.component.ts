import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-theme-dark',
  templateUrl: './theme-dark.component.html',
  styleUrls: ['./theme-dark.component.scss']
})
export class ThemeDarkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
