import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-theme-nav-fixed',
  templateUrl: './theme-nav-fixed.component.html',
  styleUrls: ['./theme-nav-fixed.component.scss']
})
export class ThemeNavFixedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
