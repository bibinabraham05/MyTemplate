import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-common-content',
  templateUrl: './common-content.component.html',
  styleUrls: ['./common-content.component.scss']
})
export class CommonContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
