import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ForgotPasswordComponent } from './modules/authentication/forgot-password/forgot-password.component';
import { LoginComponent } from './modules/authentication/login/login.component';
import { AdminComponent } from './modules/theme/layout/admin/admin.component';
import { UsersListComponent } from './modules/users/users-list/users-list.component';


const routes: Routes = 
[
  /* Routing and Navigation to login page */
  {
    path:'',
    redirectTo:'login',
    pathMatch:'full'
  },
  /* Routing and Navigation to login page */
  {
    path:'login',
    component:LoginComponent
  },
  /* Routing and Navigation to reset password page */
  {
    path:'reset-password',
    component:ForgotPasswordComponent
  },
  /* Routing and Navigation to Home page */
  {
    path: 'home',
    component: AdminComponent,
    children: [
      /* Routing and Navigation to Dashboard page */
      {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full'
      },
      /* Routing and Navigation to dashboard page, implemented lazy loading for the dashboard module */
      {
        path: 'dashboard',
        loadChildren: () => import('./modules/dashboard/dashboard.module').then(module => module.DashboardModule)
      },
      /* Routing and Navigation to sample page, implemented lazy loading for the sample page module */
      {
        path: 'sample-page',
        loadChildren: () => import('./modules/sample-page/sample-page.module').then(module => module.SamplePageModule)
      },
      /* Routing and Navigation to user profile page, implemented lazy loading for the user-profile module */
      {
        path: 'user-profile',
        loadChildren: () => import('./modules/users/user-profile/user-profile.module').then(module => module.UserProfileModule)
      },
      /* Routing and Navigation to appliance page, implemented lazy loading for the appliance module */
      {
        path: 'appliances',
        loadChildren: () => import('./modules/appliances/appliances/appliances.module').then(module => module.AppliancesModule)
      },
      /* Routing and Navigation to alerts page, implemented lazy loading for the alerts module */
      {
        path: 'alerts',
        loadChildren: () => import('./modules/alerts/alerts.module').then(module => module.AlertsModule)
      },
      /* Routing and Navigation to user-list page, implemented lazy loading for the user-list module */
      {
        path: 'user-list',
        loadChildren: () => import('./modules/users/users-list/users-list.module').then(module => module.UsersListModule)
      },
      /* Routing and Navigation to clusters page, implemented lazy loading for the clusters module */
      {
        path: 'cluster',
        loadChildren: () => import('./modules/cluster/cluster.module').then(module => module.ClusterModule)
      },
      /* Routing and Navigation to pcds page, implemented lazy loading for the pcd module */
      {
        path: 'pcds',
        loadChildren: () => import('./modules/pcd/pcd-types/pcd.module').then(module => module.PcdModule)
      },
      /* Routing and Navigation to usecase page, implemented lazy loading for the usecase module */
      {
        path: 'usecase',
        loadChildren: () => import('./modules/usecase/usecase/usecase.module').then(module => module.UsecaseModule)
      },
      /* Routing and Navigation to Jobs page, implemented lazy loading for the jobs module */
      {
        path: 'jobs',
        loadChildren: () => import('./modules/jobs/jobs/jobs.module').then(module => module.JobsModule)
      },
      /* Routing and Navigation to task page, implemented lazy loading for the task module */
      {
        path: 'task',
        loadChildren: () => import('./modules/task/task/task.module').then(module => module.TaskModule)
      }

    ]
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents = [LoginComponent, ForgotPasswordComponent]
