import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataTablesModule } from 'angular-datatables';
import { SharedModule } from '../../../shared/shared.module';
import { AppliancesRoutingModule } from './appliances-routing.module';
import { AppliancesComponent } from './appliances.component';
import { FilesUploadModule } from '../../../shared/components/files-upload/files-upload.module';
import { ApplianceDetailsComponent } from '../appliance-details/appliance-details.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';



@NgModule({
  declarations: [AppliancesComponent,ApplianceDetailsComponent],
  imports: [
    CommonModule,
    SharedModule,
    DataTablesModule,
    AppliancesRoutingModule,
    FilesUploadModule,
    NgbModule
  ]
})
export class AppliancesModule { }
