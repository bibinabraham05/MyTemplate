import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { FileUploadValidators } from '@iplab/ngx-file-upload';
import { appliances } from 'src/app/shared/models/appliances';

@Component({
  selector: 'app-appliances',
  templateUrl: './appliances.component.html',
  styleUrls: ['./appliances.component.scss']
})
export class AppliancesComponent implements OnInit {

  public showUploadCard: boolean = false; // show upload card section
  public showApplianceDetails: boolean = false; // show details card section
  public closeButton: boolean = false; // to closed the card section that has been selected
  public showResumeButton: boolean = true; // Toggle Resume and suspend button flag
  public cardTitle: string = 'Pending Activations'; // card heading
  public selectedAppliance: object; // Selected Appliance to show the details
  public appliances: appliances[] = [] // Appliance List
  public dtOptions: object; // datatables options

  
  private filesControl = new FormControl(null, FileUploadValidators.filesLimit(2));
  public demoForm = new FormGroup({
    files: this.filesControl
  });

  constructor() { 
    this.dtOptions = { 
      pageLength:10,
      lengthChange: false,
      order:[[1,'asc']],
      columnDefs: [{orderable: false,targets: [0]}]
      }
      
    this.appliances =[
      {
        appliance_name:"Appliance 00A",
        cluster_id:"ClusterID1",
        updated_on:"12 dec 2020, 9:30",
        location: "bangalore",
        deployed_usecases: ['four','one','three'],
        status:"Activated"
      },
      {
        appliance_name:"Appliance 00B",
        cluster_id:"ClusterID2",
        updated_on:"12 dec 2020, 9:30",
        location: "chennai",
        deployed_usecases: ['one','two','three'],
        status:"Scheduled"
      },
      {
        appliance_name:"Appliance 00C",
        cluster_id:"ClusterID3",
        updated_on:"12 dec 2020, 9:30",
        location: "kochi",
        deployed_usecases: ['three','six','nine'],
        status:"Suspended"
      },
      {
        appliance_name:"Appliance 00A",
        cluster_id:"ClusterID4",
        updated_on:"12 dec 2020, 9:30",
        location: "Goa",
        deployed_usecases: ['five','two','three'],
        status:"Decommisioned"
      },
      {
        appliance_name:"Appliance 00A",
        cluster_id:"ClusterID5",
        updated_on:"12 dec 2020, 9:30",
        location: "Trivandram",
        deployed_usecases: ['one','seven','nine'],
        status:"Suspended"
      }
    ]
  }

  ngOnInit() {
  }

  public toggleStatus():void{
    // this.filesControl.disabled ? this.filesControl.enable() : this.filesControl.disable();
  }

  // To activate all the Pending Activations
  public activateAll():void{
    // console.log("activate all button clicked!")
  }

  // To show upload card section
  public uploadAppliance():void{
    this.showUploadCard = true;
    this.closeButton = true;
    this.cardTitle = 'Add PCD'
  }
  
  // Select the appliance to show the details for
  public rowClickedEvent(appliance:any):void{
    this.cardTitle = appliance.appliance_name;
    this.selectedAppliance = appliance;
    this.showApplianceDetails = true;
    this.closeButton = true;
  }

  // Resume each appliance
  public resumeAppliance(appliance:any,event:any,index:any):void{
    this.appliances[index]['status'] = 'Activated'
    event.stopPropagation();
    this.showResumeButton = false;
  }

  // suspend each appliance
  public suspendAppliance(appliance:any,event:any,index:any):void{
    this.appliances[index]['status'] = 'Suspended'
    event.stopPropagation();
    this.showResumeButton = true;
  }
  
  // to close each card section
  public closeInfoBar():void{
    this.showApplianceDetails = false;
    this.showUploadCard = false;
    this.closeButton = false;
  }
  
}
