import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl } from '@angular/forms';

import { AppliancesComponent } from './appliances.component';

describe('AppliancesComponent', () => {
  let fixture: AppliancesComponent;
  const event = { stopPropagation: () => {} };
  const appliance =
    {
      appliance_name:"Appliance 00A",
      cluster_id:"ClusterID1",
      updated_on:"12 dec 2020, 9:30",
      location: "bangalore",
      deployed_usecases: ['four','one','three'],
      status:"Suspended"
    }


  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AppliancesComponent ],      
      schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = new AppliancesComponent();
    fixture.ngOnInit();
    jest.spyOn(event,'stopPropagation');
  });

  describe('Test: toggleStatus', () => {
    it('should toggle upload action', () => {
      fixture.toggleStatus();
    })
  })

  describe('Test: activateAll', () => {
    it('Should activate all', () => {
      fixture.activateAll();
    })
  })

  describe('Test: UploadAppliance', () => {
    it('Should show upload section', () => {
      fixture.uploadAppliance();
      expect(fixture.showUploadCard).toEqual(true);
      expect(fixture.closeButton).toEqual(true);
      expect(fixture.cardTitle).toEqual('Add PCD');

    })
  })

  describe('Test: rowClickedEvent', () => {
    it('Should show aplliance Details', () => {
      fixture.rowClickedEvent(appliance);
      fixture.showUploadCard = true;
      expect(fixture.showUploadCard).toBe(true);
    })
  })

  describe('Test: resumeAppliance', () => {
    it('Should resume Appliance', () => {
      fixture.resumeAppliance(appliance,event,1);
      appliance.status = 'Activated';
      expect(appliance.status).toEqual('Activated');
      expect(event.stopPropagation).toHaveBeenCalled();
      expect(fixture.showResumeButton).toEqual(false);
    })
  })

  describe('Test: pauseAppliance', () => {
    it('Should pause Appliance', () => {
      fixture.suspendAppliance(appliance,event,1);
      appliance.status = 'Suspended';
      expect(appliance.status).toEqual('Suspended');
      expect(event.stopPropagation).toHaveBeenCalled();
      expect(fixture.showResumeButton).toEqual(true);
    })
  })

  describe('Test: closeInfoBar', () => {
    it('Shouls close the info bar', () => {
      fixture.closeInfoBar();
      expect(fixture.showApplianceDetails).toEqual(false);
      expect(fixture.showUploadCard).toEqual(false);
      expect(fixture.closeButton).toEqual(false);

    })
  })
  

});
