import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ApexChartService } from 'src/app/shared/components/chart/apex-chart/apex-chart.service';

@Component({
  selector: 'app-appliance-details',
  templateUrl: './appliance-details.component.html',
  styleUrls: ['./appliance-details.component.scss']
})
export class ApplianceDetailsComponent implements OnInit {
  @Input() selectedAppliance: any;
  @Input() cardTitle: string;
  @Output() closeDetailsEvent = new EventEmitter<boolean>();
  area1CAC: any = { };
  appliance_name: any;

  constructor(public apexEvent: ApexChartService) {
  this.area1CAC = {
    chart: {
      height: 350,
      type: 'area',
    },
    dataLabels: {
      enabled: false
    },
    stroke: {
      curve: 'smooth'
    },
    colors: ['#00acc1', '#ff5252', '#ffa21d'],
    series: [{
      name: 'CPU',
      data: [31, 40, 28, 51, 42, 109, 100]
    }, {
      name: 'Memory',
      data: [11, 32, 45, 32, 34, 52, 41]
    }, {
      name: 'Disk Usage',
      data: [80, 32, 25, 62, 44, 22, 81]
    }],

    xaxis: {
      type: 'datetime',
      categories: [
        '2018-09-19T00:00:00',
        '2018-09-19T01:30:00',
        '2018-09-19T02:30:00',
        '2018-09-19T03:30:00',
        '2018-09-19T04:30:00',
        '2018-09-19T05:30:00',
        '2018-09-19T06:30:00'
      ],
    },
    tooltip: {
      x: {
        format: 'dd/MM/yy HH:mm'
      },
    }
  }; }

  ngOnInit(): void {
    console.log("Selected Job",this.selectedAppliance)
    this.appliance_name = this.selectedAppliance.appliance_name;
  }

  closeInfoBar(){
    this.closeDetailsEvent.emit(true);
  }
}
