import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataTablesModule } from 'angular-datatables';
import { SharedModule } from '../../../shared/shared.module';
import { JobsComponent } from './jobs.component';
import { JobsRoutingModule } from './jobs-routing.module';
import { FilesUploadModule } from '../../../shared/components/files-upload/files-upload.module';
import { JobDetailsComponent } from '../job-details/job-details.component';



@NgModule({
  declarations: [JobsComponent,JobDetailsComponent],
  imports: [
    CommonModule,
    SharedModule,
    DataTablesModule,
    JobsRoutingModule,
    FilesUploadModule
  ]
})
export class JobsModule { }
