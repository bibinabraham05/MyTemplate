import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { FileUploadValidators } from '@iplab/ngx-file-upload';
import { Jobs } from 'src/app/shared/models/jobs';

@Component({
  selector: 'app-jobs',
  templateUrl: './jobs.component.html',
  styleUrls: ['./jobs.component.scss']
})
export class JobsComponent implements OnInit {

  showUploadCard: boolean = false; // show upload card section
  cardTitle: string; // card section title
  showJobDetails: boolean = false; // show job details card flag
  jobs: Jobs[] = []; // job list
  selectedJob: any; // selected job to show details for
  
  private filesControl = new FormControl(null, FileUploadValidators.filesLimit(2));
  public demoForm = new FormGroup({
    files: this.filesControl
  });

  constructor() { 
    this.jobs =[
      {
        job_name:"JOB 00A",
        cluster_id:"ClusterID1",
        usecase:"Usecase1",
        ticket_count:"30000",
        updated_ticket_count:"20000",
        consumed: "10000"
      },
      {
        job_name:"JOB 00B",
        cluster_id:"ClusterID2",
        usecase:"Usecase2",
        ticket_count: "400000",
        updated_ticket_count:"30000",
        consumed: "30000"
      },
      {
        job_name:"JOB 00C",
        cluster_id:"ClusterID3",
        usecase:"Usecase3",
        ticket_count:"40000",
        updated_ticket_count:"5000",
        consumed: "8000"
      },
    ]
  }

  ngOnInit() {
  }

  public toggleStatus() {
    this.filesControl.disabled ? this.filesControl.enable() : this.filesControl.disable();
  }

  // show upload card section
  showUpload(){
    this.showUploadCard = true;
    this.showJobDetails = false;
    this.cardTitle = 'Upload Job'
  }
  
  // Select each job to show the details for
  rowClickedEvent(job:any,event:any){
    this.showJobDetails = true;
    this.showUploadCard = false;
    this.cardTitle = job.job_name
    this.selectedJob = job;
  }
  
  // close each card section
  closeInfoBar(){
    this.showUploadCard = false;
    this.showJobDetails = false;
  }

}
