import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-job-details',
  templateUrl: './job-details.component.html',
  styleUrls: ['./job-details.component.scss']
})
export class JobDetailsComponent implements OnInit {
  @Input() selectedJob: any;
  @Input() cardTitle: string;
  @Output() closeDetailsEvent = new EventEmitter<boolean>();

  constructor() { }

  ngOnInit(): void {
    console.log("Selected Job",this.selectedJob)
  }

  closeInfoBar(){
    this.closeDetailsEvent.emit(true);
  }
}
