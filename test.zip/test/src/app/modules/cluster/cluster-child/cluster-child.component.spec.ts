import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClusterChildComponent } from './cluster-child.component';

describe('ClusterChildComponent', () => {
  let component: ClusterChildComponent;
  let fixture: ComponentFixture<ClusterChildComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClusterChildComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClusterChildComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
