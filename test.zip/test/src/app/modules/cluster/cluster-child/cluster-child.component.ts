import { Component, Input, OnInit, Output } from '@angular/core';
import { EventEmitter } from 'events';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-cluster-child',
  templateUrl: './cluster-child.component.html',
  styleUrls: ['./cluster-child.component.css']
})
export class ClusterChildComponent implements OnInit {
  public dtOptions: DataTables.Settings = {};

  @Input() data: any[];
  //subject to throw events to parent component
  public clickEvent = new Subject();

  public appliances: any[];
  constructor() { }

  ngOnInit(): void {
    this.dtOptions = {
      paging: false, searching: false,
      order:[]
    }
    this.appliances =[
      {
        appliance_name:"Appliance 00A",
        cluster_id:"ClusterID1",
        createdOn:"12 dec 2020, 9:30",
        location:"Texas",
        status:"Activated"
      },
      {
        appliance_name:"Appliance 00B",
        cluster_id:"ClusterID1",
        createdOn:"12 dec 2020, 9:30",
        location:"Newyork",
        status:"Scheduled"
      },
    ]
  }
  confirmDismiss(event:any,appliance:any){
    event.stopPropagation();
  }
  //Method used to throw click event to parent
  rowClicked(appliance:any){
this.clickEvent.next(appliance);
  }
}
