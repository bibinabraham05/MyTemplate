import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ClusterComponent } from './cluster.component';
import { ClusterRoutingModule } from './cluster-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { DataTablesModule } from 'angular-datatables';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ClusterChildComponent } from './cluster-child/cluster-child.component';



@NgModule({
  declarations: [ClusterComponent, ClusterChildComponent],
  imports: [
    CommonModule,
    ClusterRoutingModule,
    SharedModule,
    DataTablesModule,
    NgbModule
  ]
})
export class ClusterModule { }
