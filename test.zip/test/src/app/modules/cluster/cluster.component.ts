import { Component, OnInit, ViewChild,OnDestroy, ComponentFactoryResolver, ViewContainerRef, Renderer2, ComponentRef } from '@angular/core';
import { DataTableDirective } from 'angular-datatables';
import { Subject } from 'rxjs';
import { ClusterService } from 'src/app/core/services/cluster.service';
import { ClusterChildComponent } from './cluster-child/cluster-child.component';

@Component({
  selector: 'app-cluster',
  templateUrl: './cluster.component.html',
  styleUrls: ['./cluster.component.scss']
})
export class ClusterComponent implements OnInit, OnDestroy {
  @ViewChild(DataTableDirective)
  dtElement: DataTableDirective;// Data tabe element
  public dtOptions: DataTables.Settings = {};//Data table options
  private childRow: ComponentRef<ClusterChildComponent>;//Dynamic row reference
  private dtTrigger: Subject<any> = new Subject();
  public clusters:any;//Variable to hold cluster data
  public selectedCluster: any;
  constructor(private clusterService:ClusterService,
    private compFactory: ComponentFactoryResolver,
    private viewRef: ViewContainerRef,
    private _renderer: Renderer2) { }

  ngOnInit(): void {
    this.getClusterList();
    //Setting default page size and removing length dropdown
    this.dtOptions = {
      pageLength:10,
      lengthChange: false,
      order:[]
    }
  }
/* Method to get the cluster list */
  getClusterList():void{
this.clusterService.getCluster().subscribe((data)=>{
this.clusters=data?.clusters;
},
error=>{
  console.log(error)
  this.clusters=[];
})
  }
  //Creating dynamic row to display nested table
  expandRow(trRef, rowData):void {
    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      var row = dtInstance.row(trRef);
      if (row.child.isShown()) {
        row.child.hide();
        this._renderer.removeClass(trRef, 'shown');
      }
      else {
        let factory = this.compFactory.resolveComponentFactory(ClusterChildComponent);
        this.childRow = this.viewRef.createComponent(factory);
        this.childRow.instance.data = [rowData];
        //subscribe to click event from child dynamic component
        this.childRow.instance.clickEvent.subscribe(data=>{console.log(data,"child data")});
        // this.childRow
        row.child(this.childRow.location.nativeElement).show();
        this._renderer.addClass(trRef, 'shown');
      }
    })
  }

  /* Dismiss button click event */
  confirmDismiss(event:any,cluster:any){
    event.stopPropagation();
  }
  ngOnDestroy() {
  }

}
