import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { IUser } from '../../../shared/models/iuser';
import { UsersService } from '../../../core/services/users.service';
import { AddUserComponent } from './add-user/add-user.component';
import { EditUserComponent } from './edit-user/edit-user.component';
import { promise } from 'protractor';
import { DataTableDirective } from 'angular-datatables';

@Component({
  selector: 'app-users-list',
  templateUrl: './users-list.component.html',
  styleUrls: ['./users-list.component.scss']
})
export class UsersListComponent implements OnInit, OnDestroy {
  private subscription: Subject<any> = new Subject();

  public dtOptions: DataTables.Settings = {};//variable to specify data table options
  public dismissUser: string;//variable to store dismissed user username
  public infobarOn: boolean = false;//flag variable to open and close details card
  public selectedUser: IUser;//variable to store the selected user
  public users: IUser[] = [
    {
      "id": "USER ID 00A",
      "firstName": "Thi",
      "lastName": "Nguyen",
      "email": "thinguyen@rambus.com",
      "group": "Admin",
      "status": "Online",
      "loginTime": "12 dec 2020, 9:30",
      "creationDate": "19 dec 2019, 9:30"
    },
    {
      "id": "USER ID 00B",
      "firstName": "Quinn",
      "lastName": "Flinn",
      "email": "quinnflinn@rambus.com",
      "group": "Operator",
      "status": "Offline",
      "loginTime": "12 dec 2020, 9:30",
      "creationDate": "19 dec 2019, 9:30"
    },
    {
      "id": "USER ID 00C",
      "firstName": "Garret",
      "lastName": "Winters",
      "email": "garretwinters@rambus.com",
      "group": "Operator",
      "status": "Offline",
      "loginTime": "12 dec 2020, 9:30",
      "creationDate": "19 dec 2019, 9:30"
    },
    {
      "id": "USER ID 00D",
      "firstName": "Ashton",
      "lastName": "Cox",
      "email": "ashtoncox@rambus.com",
      "group": "Operator",
      "status": "Online",
      "loginTime": "12 dec 2020, 9:30",
      "creationDate": "19 dec 2019, 9:30"
    },
    {
      "id": "USER ID 00E",
      "firstName": "Airie",
      "lastName": "Satou",
      "email": "airiesatou@rambus.com",
      "group": "Operator",
      "status": "Offline",
      "loginTime": "12 dec 2020, 9:30",
      "creationDate": "19 dec 2019, 9:30"
    },
    {
      "id": "USER ID 00F",
      "firstName": "Cedric",
      "lastName": "Kelly",
      "email": "cedrickelly@rambus.com",
      "group": "Operator",
      "status": "Online",
      "loginTime": "12 dec 2020, 9:30",
      "creationDate": "19 dec 2019, 9:30"
    },
    {
      "id": "USER 008",
      "firstName": "Thi",
      "lastName": "Nguyen",
      "email": "thinguyen@rambus.com",
      "group": "Admin",
      "status": "Online",
      "loginTime": "12 dec 2020, 9:30",
      "creationDate": "19 dec 2019, 9:30"
    },
    {
      "id": "USER 009",
      "firstName": "Thi",
      "lastName": "Nguyen",
      "email": "thinguyen@rambus.com",
      "group": "Admin",
      "status": "Online",
      "loginTime": "12 dec 2020, 9:30",
      "creationDate": "19 dec 2019, 9:30"
    }, {
      "id": "USER ID 00B",
      "firstName": "Quinn",
      "lastName": "Flinn",
      "email": "quinnflinn@rambus.com",
      "group": "Operator",
      "status": "Offline",
      "loginTime": "12 dec 2020, 9:30",
      "creationDate": "19 dec 2019, 9:30"
    },
    {
      "id": "USER ID 00C",
      "firstName": "Garret",
      "lastName": "Winters",
      "email": "garretwinters@rambus.com",
      "group": "Operator",
      "status": "Offline",
      "loginTime": "12 dec 2020, 9:30",
      "creationDate": "19 dec 2019, 9:30"
    },
    {
      "id": "USER ID 00D",
      "firstName": "Ashton",
      "lastName": "Cox",
      "email": "ashtoncox@rambus.com",
      "group": "Operator",
      "status": "Online",
      "loginTime": "12 dec 2020, 9:30",
      "creationDate": "19 dec 2019, 9:30"
    },];

  private closeResult: string;
  constructor(private modalService: NgbModal, private userService: UsersService) {

  }

  ngOnDestroy() {
    this.subscription.next();
    this.subscription.complete();
  }

  ngOnInit() {

    this.dtOptions = {
      pageLength: 10,
      lengthChange: false
    }
    // this.getUsersList();
  }
  //Method to get user data
  getUsersList(): void {

    this.userService.getUsersList().subscribe(
      result => {
        // this.users = result;
      }, (err) => {
        // this.users = [];
      });
  }
  // Method to act on click event of table row
  rowClickedEvent(user: IUser, event: any): void {
    this.infobarOn = true;
    this.selectedUser = user;
  }
  //Method to open user edit popup
  editUser(event: any, user: IUser): void {
    event.stopPropagation();
    this.openEditUser(user);
  }
  //Method to change close info bar flag 
  closeInfoBar(): void {
    this.infobarOn = false;
  }
  //Method to open add user popup
  openAddUser(): void {
    this.modalService.open(AddUserComponent, { ariaLabelledBy: 'modal-basic-title' })
  }
  //Method to open add user popup
  openEditUser(user: IUser): void {
    const modalRef = this.modalService.open(EditUserComponent, { ariaLabelledBy: 'modal-basic-title' });
    modalRef.componentInstance.data = user;
  }
  //Method to show confirmation popup
  confirmDismiss(event: any, myPersistenceModal: any, id: string): void {
    event.stopPropagation();
    myPersistenceModal.show();
    this.dismissUser = id;
  }

}
