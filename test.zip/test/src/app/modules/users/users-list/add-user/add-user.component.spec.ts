import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms';

import { AddUserComponent } from './add-user.component';

describe('AddUserComponent', () => {
  let component: AddUserComponent;
  let fixture: AddUserComponent;
  let activeModalMock:any;
  let fbMock:FormBuilder;


  beforeEach(() => {
    activeModalMock={close:()=>{}};
    fbMock= new FormBuilder();
    fixture = new AddUserComponent(activeModalMock,fbMock);
    fixture.ngOnInit();
  });
 describe('Test: ngOnInit',()=>{
   it('should call initialize form',()=>{
    const initializeFormMock = jest.spyOn(fixture,'initializeForm');
    expect(initializeFormMock).not.toHaveBeenCalled();
   })
 })
 describe('Test: initializeForm',()=>{
  it('should initialize userForm',()=>{
    const MockuserForm = {
      firstName: '',
      lastName: '',
      userName: '',
      role:'',
      email: '',
      companyName:'',
      contactNumber:'',
      location:'',
      password:'',
      confirmPassword:'',
    };
    expect(fixture.userForm.value).toEqual(MockuserForm);
  })
})
describe('Test : addUser function',()=>{
  it('Should add user',()=>{
    fixture.addUsers()
    expect(fixture.submitted).toBeTruthy();
  }
  )
})
describe('Test : mustMatch',()=>{
  it('should test whether the password data is matching : matching condition',()=>{
   fixture.userForm.controls.password.setValue('User@123');
   fixture.userForm.controls.confirmPassword.setValue('User@123');
   fixture.MustMatch('password', 'confirmPassword');
   expect(fixture.userForm.controls.confirmPassword.errors).toBeFalsy();
  })
  it('should test whether the password data is matching : password mismatch',()=>{
    fixture.userForm.controls.password.setValue('User@123');
    fixture.userForm.controls.confirmPassword.setValue('User@321');
    fixture.MustMatch('password', 'confirmPassword');
    expect(fixture.userForm.controls.confirmPassword.errors.mustMatch).toBeTruthy;
   })
})
});
