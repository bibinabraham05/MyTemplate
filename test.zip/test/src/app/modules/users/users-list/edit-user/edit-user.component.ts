import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {
  public displayData:any;
  @Input() data:any;
  userForm: FormGroup;
  submitted = false;
  constructor(public activeModal: NgbActiveModal,private fb: FormBuilder) { 
  }
  
  ngOnInit(): void {
  this.displayData=this.data;
  this.initializeForm();
  }
  initializeForm() {
    this.userForm = this.fb.group({
      firstName: [this.displayData.firstName?this.displayData.firstName:'', Validators.required],
      lastName: [this.displayData.lastName?this.displayData.lastName:'', Validators.required],
      userName: [this.displayData.id?this.displayData.id:'', Validators.required],
      role: [this.displayData.group?this.displayData.group:'', Validators.required],
      email: [this.displayData.email?this.displayData.email:'', [Validators.required, Validators.email]],
      companyName: ['', Validators.required],
      contactNumber: ['', Validators.required],
      location: ['', Validators.required],
    })
  }

  get f() { return this.userForm.controls; }
}
