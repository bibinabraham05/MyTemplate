import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms';

import { EditUserComponent } from './edit-user.component';

describe('EditUserComponent', () => {
  let fixture: EditUserComponent;
  let activeModalMock:any;
  let fbMock:FormBuilder;
  let mockData={
  "id": "USER ID 00D",
  "firstName": "Ashton",
  "lastName": "Cox",
  "email": "ashtoncox@rambus.com",
  "group": "Operator",
  "status": "Online",
  "loginTime": "12 dec 2020, 9:30",
  "creationDate": "19 dec 2019, 9:30"
   }

  beforeEach(() => {
    activeModalMock={close:()=>{}};
    fbMock= new FormBuilder();
    fixture = new EditUserComponent(activeModalMock,fbMock);
    fixture.data=mockData;
    fixture.ngOnInit();
  });
 describe('Test: ngOnInit',()=>{
   it('should call initialize form',()=>{
    const initializeFormMock = jest.spyOn(fixture,'initializeForm');
    expect(initializeFormMock).not.toHaveBeenCalled();
   })
 })
 describe('Test: initializeForm',()=>{
  it('should initialize userForm',()=>{
    const MockuserForm = {
      firstName: mockData.firstName ,
      lastName: mockData.lastName,
      userName: mockData.id,
      role:mockData.group,
      email: mockData.email,
      companyName:'',
      contactNumber:'',
      location:'',
    };
    expect(fixture.userForm.value).toEqual(MockuserForm);
  })
})
});
