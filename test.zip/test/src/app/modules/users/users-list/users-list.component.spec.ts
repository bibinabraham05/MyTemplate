import { CommonModule } from '@angular/common';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { NgbModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DataTablesModule } from 'angular-datatables';
import { Subject } from 'rxjs';
import { IUser } from 'src/app/shared/models/iuser';
import { SharedModule } from 'src/app/shared/shared.module';
import { EditUserComponent } from './edit-user/edit-user.component';
import { UsersListRoutingModule } from './users-list-routing.module';

import { UsersListComponent } from './users-list.component';
import { UsersListModule } from './users-list.module';

describe('UsersListComponent', () => {
  let component: UsersListComponent;
  let fixture: UsersListComponent;
  let userServiceMock:any;
  let modalServiceMock:NgbModal;
  let subscriptionMock:Subject<any>;
  const event = { stopPropagation: () => {} };
  let user:IUser={
    "id": "USER ID 00D",
    "firstName": "Ashton",
    "lastName": "Cox",
    "email": "ashtoncox@rambus.com",
    "group": "Operator",
    "status": "Online",
    "loginTime": "12 dec 2020, 9:30",
    "creationDate": "19 dec 2019, 9:30"
  };
  beforeEach(() => {
    userServiceMock={
      getUsersList:jest.fn()
    }
    modalServiceMock=TestBed.inject(NgbModal);
    subscriptionMock = new Subject();
    fixture = new UsersListComponent(modalServiceMock,userServiceMock)
    fixture.ngOnInit();
  });
describe('test : ngOnInit',()=>{
  it("Should initialize dtOptions",()=>{
  let dtOptionsTemp={
    pageLength:10,
    lengthChange:false
  }
  expect(fixture.dtOptions).toEqual(dtOptionsTemp);
  })
  // it("Should call getUsersList function",()=>{
  // const getUserSpyMock = jest.spyOn(fixture,'getUsersList');
  // expect(getUserSpyMock).toHaveBeenCalled();
  // })
});
describe("test : getUserlist",()=>{
  it('should get user list',()=>{
    const response = {
      success: true,
      data: {}
    };
    const spygetUser = jest.spyOn(userServiceMock, 'getUsersList').mockReturnValue(response);
    expect(userServiceMock.getUsersList()).toBe(response);
    expect(spygetUser).toHaveBeenCalled();
  })
})
describe('Test : ngOnDestroy',()=>{
  it('should unsubscribe', () => {
    fixture.ngOnDestroy();
    const spysubscriptionNext = jest.spyOn(subscriptionMock,'next');
    const spysubscriptionComplete=jest.spyOn(subscriptionMock,'complete')
    expect(spysubscriptionNext).toBeDefined();
    expect(spysubscriptionComplete).toBeDefined();
  });
})
describe('Test : rowClickedEvent',()=>{
  it('Should display user details when user selected',()=>{
    fixture.rowClickedEvent(user,event);
    expect(fixture.infobarOn).toBeTruthy();
    expect(fixture.selectedUser).toEqual(user);
  })
})
describe('Test :editUser function',()=>{
  it('Should open edit user popup and event stop propagation',()=>{
    const stopPropagationMock =jest.spyOn(event,'stopPropagation');
    expect(stopPropagationMock).toBeDefined();
    const openEditUserMock = jest.spyOn(fixture,'openEditUser');
    expect(openEditUserMock).toBeDefined();
  })
})
describe('Test :closeInfoBar',()=>{
  it('Should set infobarOn variable to false',()=>{
    fixture.closeInfoBar();
    expect(fixture.infobarOn).toBeFalsy();
  })
})
describe('Test :openEditUser',()=>{
  it('Should open edit user popup',()=>{
  const spyEditUserOpen = jest.spyOn(modalServiceMock,'open');
  expect(spyEditUserOpen).toBeDefined();
  })
})
describe('Test : openAddUser',()=>{
it('should open add user popup',()=>{
  const spyAddUserOpen = jest.spyOn(modalServiceMock,'open');
  expect(spyAddUserOpen).toBeDefined();
})
})
describe('Test :confirmDismiss',()=>{
  it('to show confirmation popup',()=>{
    let myPersistenceModalMock={show:()=>{}};
    let idMock="User ID 00A"
    fixture.confirmDismiss(event,myPersistenceModalMock,idMock);
    const stopPropagationMock =jest.spyOn(event,'stopPropagation');
    expect(stopPropagationMock).toBeDefined();
    const showMethodMock = jest.spyOn(myPersistenceModalMock,'show');
    expect(showMethodMock).toBeDefined();
    expect(fixture.dismissUser).toEqual(idMock);
  })
})
});

