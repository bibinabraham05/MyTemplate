import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { LoginComponent } from './login.component';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ ReactiveFormsModule, FormsModule ],
      declarations: [ LoginComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.ngOnInit();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('form to be invalid when empty', () => {
    expect(component.cmccLoginForm.valid).toBeFalsy();
  });

  it('Username validity', () => {
    let username = component.cmccLoginForm.controls['username']
    expect(username.valid).toBeFalsy();

    let errors = {};

    errors = username.errors || {};
    expect(errors['required']).toBeTruthy();

    username.setValue('user123');
    expect(username.valid).toBeTruthy();
  });

  it('Password validity', () => {
    let password = component.cmccLoginForm.controls['password']
    expect(password.valid).toBeFalsy();    

    let errors = {};

    errors = password.errors || {};
    expect(errors['required']).toBeTruthy();

    password.setValue('passwrod#45');
    expect(password.valid).toBeTruthy();
  });

  it('Should call the function cmccLogin', ()=>{
    if(component.cmccLoginForm.valid){      
      expect(component.cmccLogin()).toBe(true);
    }
  })
  

});
