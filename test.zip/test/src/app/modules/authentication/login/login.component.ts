import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  cmccLoginForm: FormGroup; // formgroup for user login

  constructor(private formBuilder: FormBuilder,private router: Router) { }

  ngOnInit(): void {
    this.cmccLoginForm = this.formBuilder.group({      
      username: ['', Validators.required] ,    // CMCC user id
      password: ['', Validators.required]      // CMCC user password
    })
  }

  cmccLogin(){
    if(this.cmccLoginForm.valid){   
      this.router.navigate(['home']);
      return true
    }else{
      alert("Please fill in the required fields")
      return false
    }
  }

}
