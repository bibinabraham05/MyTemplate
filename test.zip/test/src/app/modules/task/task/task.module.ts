import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataTablesModule } from 'angular-datatables';
import {SharedModule} from '../../../shared/shared.module';
import { TaskRoutingModule } from './task-routing.module';
import { TaskComponent } from './task.component';



@NgModule({
  declarations: [TaskComponent],
  imports: [
    CommonModule,
    SharedModule,
    DataTablesModule,
    TaskRoutingModule
  ]
})
export class TaskModule { }
