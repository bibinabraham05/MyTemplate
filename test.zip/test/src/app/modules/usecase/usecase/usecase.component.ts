import { Component, OnInit } from '@angular/core';
import { IUseCase } from '../../../shared/models/iusecase';

@Component({
  selector: 'app-usecase',
  templateUrl: './usecase.component.html',
  styleUrls: ['./usecase.component.scss']
})
export class UsecaseComponent implements OnInit {

  public dtOptions: any = {}; // to set data table options
  public useCases: IUseCase[] = [ //to set useCase values
    {
      slNo: 1,
      useCaseId:"Use Case 00A",
      deployed: true,
      status: "Deployed",
      ticketCount: 100,
      moduleId: "Module 001",
      uploadedDate: "12 Dec 2020, 12:30",
      jobId: "Job ID 1000"
    },
    {
      slNo: 2,
      useCaseId:"Use Case 00B",
      deployed: false,
      status: "Not Deployed",
      ticketCount: 200,
      moduleId: "Module 001",
      uploadedDate: "12 Dec 2020, 12:30",
      jobId: "Job ID 1001"
    },
    {
      slNo: 3,
      useCaseId:"Use Case 00C",
      deployed: true,
      status: "Deployed",
      ticketCount: 300,
      moduleId: "Module 001",
      uploadedDate: "12 Dec 2020, 12:30",
      jobId: "Job ID 1002"
    },
    {
      slNo: 4,
      useCaseId:"Use Case 00D",
      deployed: true,
      status: "Deployed",
      ticketCount: 150,
      moduleId: "Module 001",
      uploadedDate: "12 Dec 2020, 12:30",
      jobId: "Job ID 1003"
    },
  ];

  constructor() {
    // setting data table options
    this.dtOptions = { 
      pageLength:10,
      lengthChange: false,
      order:[[1,'asc']],
      columnDefs: [{orderable: false,targets: [0]}]
      }
   }

  ngOnInit(): void {
  }

  // To deploy current use case which is Not deployed
  deployCurrentUseCase(useCase): void {
    useCase.deployed = !useCase.deployed;
    useCase.status = (!useCase.deployed)? "Not Deployed" : "Deployed"; 
  }
  // To delete the selected use case
  removeCurrentUseCase(useCase): void {
    useCase.deployed = false;
    useCase.status = "Removed";
    // (!useCase.deployed)? "Removed" : "Deployed"; 
  }
}
