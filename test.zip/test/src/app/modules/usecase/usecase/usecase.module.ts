import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UsecaseComponent } from './usecase.component';
import { DataTablesModule } from 'angular-datatables';
import {SharedModule} from '../../../shared/shared.module';
import { UsecaseRoutingModule } from './usecase-routing.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { UsecasePackageComponent } from '../usecase-package/usecase-package.component';
import { FilesUploadModule } from 'src/app/shared/components/files-upload/files-upload.module';
import { UsecaseDetailsComponent } from '../usecase-details/usecase-details.component';



@NgModule({
  declarations: [UsecaseComponent,UsecasePackageComponent, UsecaseDetailsComponent],
  imports: [
    CommonModule,
    SharedModule,
    DataTablesModule,
    UsecaseRoutingModule,
    NgbModule,
    FilesUploadModule
  ]
})
export class UsecaseModule { }
