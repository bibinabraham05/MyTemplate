import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsecaseComponent } from './usecase.component';

describe('UsecaseComponent', () => {
  let component: UsecaseComponent;
  let fixture: UsecaseComponent;

  const useCases  = [
    {
      slNo: 1,
      useCaseId:"Use Case 00A",
      deployed: true,
      status: "Deployed",
      ticketCount: 100,
      moduleId: "Module 001",
      uploadedDate: "12 Dec 2020, 12:30",
      jobId: "Job ID 1000"
    },
    {
      slNo: 2,
      useCaseId:"Use Case 00B",
      deployed: false,
      status: "Not Deployed",
      ticketCount: 200,
      moduleId: "Module 001",
      uploadedDate: "12 Dec 2020, 12:30",
      jobId: "Job ID 1001"
    },
    {
      slNo: 3,
      useCaseId:"Use Case 00C",
      deployed: true,
      status: "Deployed",
      ticketCount: 300,
      moduleId: "Module 001",
      uploadedDate: "12 Dec 2020, 12:30",
      jobId: "Job ID 1002"
    },
    {
      slNo: 4,
      useCaseId:"Use Case 00D",
      deployed: true,
      status: "Deployed",
      ticketCount: 150,
      moduleId: "Module 001",
      uploadedDate: "12 Dec 2020, 12:30",
      jobId: "Job ID 1003"
    },
  ];

  beforeEach(() => {
    fixture = new UsecaseComponent();
    fixture.useCases = useCases;
    fixture.ngOnInit();
  });
  
  describe('Test: deployCurrentUseCase', () => {
    it('should call deployCurrentUseCase', () => {
      fixture.deployCurrentUseCase(useCases[0]);
      // expect(fixture.deployCurrentUseCase.arguments[0].status).toEqual('Deployed');
    })
  })
  describe('Test: deployCurrentUseCase', () => {
    it('should call deployCurrentUseCase', () => {
      fixture.deployCurrentUseCase(useCases[1]);
      // expect(fixture.deployCurrentUseCase.arguments[0].status).toEqual('Not Deployed');
    })
  })

  describe('Test: removeCurrentUseCase', () => {
    it('should call removeCurrentUseCase', () => {
      fixture.removeCurrentUseCase(useCases[0]);
    })
  })
});
