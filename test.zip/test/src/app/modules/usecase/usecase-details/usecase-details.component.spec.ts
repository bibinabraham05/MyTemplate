import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsecaseDetailsComponent } from './usecase-details.component';

describe('UsecaseDetailsComponent', () => {
  let component: UsecaseDetailsComponent;
  let fixture: UsecaseDetailsComponent;
  
  beforeEach(() => {
    fixture = new UsecaseDetailsComponent();
    fixture.ngOnInit();
  });
  
  describe('Test: closeInfoBar', () => {
    it('should close the details card on click of closeInfoBar()', () => {
      fixture.closeInfoBar();
    })
  })
});
