import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-usecase-details',
  templateUrl: './usecase-details.component.html',
  styleUrls: ['./usecase-details.component.css']
})
export class UsecaseDetailsComponent implements OnInit {

  @Input() selectedUseCase: any; // to hold the selected use case value
  @Input() cardTitle: string; // to hold the card title
  @Output() closeDetailsEvent = new EventEmitter<boolean>(); // to emit the event when card is closed

  constructor() { }

  ngOnInit(): void {
    console.log("Selected UseCase",this.selectedUseCase)
  }

  //to close the use case details card section
  closeInfoBar(): void{ 
    this.closeDetailsEvent.emit(true);
  }

}
