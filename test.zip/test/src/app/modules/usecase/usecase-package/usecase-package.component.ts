import { Component, OnInit } from '@angular/core';
import { IUseCase } from '../../../shared/models/iusecase';

@Component({
  selector: 'app-usecase-package',
  templateUrl: './usecase-package.component.html',
  styleUrls: ['./usecase-package.component.css']
})
export class UsecasePackageComponent implements OnInit {
  public showUploadCard: boolean = false; // to show upload card session
  public showUsecasePackageDetails: boolean = false; // to show usecase package details
  public cardTitle: string; // to show the card title on details page
  public showUseCaseDetails: boolean = false; // show details section flag
  public selectedUseCase: any; //to hold the selected usecase value
  public dtOptions: any={}; //for setting the Data table options
  public useCases: IUseCase[] = [ //to set useCase values
    {
      slNo: 1,
      useCaseId:"Use Case 00A",
      deployed: true,
      status: "Deployed",
      ticketCount: 100,
      moduleId: "Module 001",
      uploadedDate: "12 Dec 2020, 12:30",
      jobId: "Job ID 1000"
    },
    {
      slNo: 2,
      useCaseId:"Use Case 00B",
      deployed: false,
      status: "Not Deployed",
      ticketCount: 200,
      moduleId: "Module 001",
      uploadedDate: "12 Dec 2020, 12:30",
      jobId: "Job ID 1001"
    },
    {
      slNo: 3,
      useCaseId:"Use Case 00C",
      deployed: true,
      status: "Deployed",
      ticketCount: 300,
      moduleId: "Module 001",
      uploadedDate: "12 Dec 2020, 12:30",
      jobId: "Job ID 1002"
    },
    {
      slNo: 4,
      useCaseId:"Use Case 00D",
      deployed: true,
      status: "Deployed",
      ticketCount: 150,
      moduleId: "Module 001",
      uploadedDate: "12 Dec 2020, 12:30",
      jobId: "Job ID 1003"
    },
  ];

  constructor() {
    /* Setting data table options */
    this.dtOptions = { 
      pageLength:10,
      lengthChange: false,
      order:[[1,'asc']],
      columnDefs: [{orderable: false,targets: [0]}]
      }
   }

  ngOnInit(): void {
  }

  /* To delete selected use case */
  deleteUseCase(): void{

  }

  // select each useCase to show details
  rowClickedEvent(useCase:any,event:any): void{
    this.showUseCaseDetails = true;
    this.showUploadCard = false;
    this.cardTitle = useCase.pcd_name
    this.selectedUseCase = useCase;
  }

  
  // show upload card section
  showUpload(): void{
    this.showUploadCard = true;
    this.cardTitle = 'Upload Usecase Package'
  }

  // close each card section
  closeInfoBar(): void{
    this.showUploadCard = false;
    this.showUsecasePackageDetails = false;
    this.showUseCaseDetails = false;
  }
  
}
