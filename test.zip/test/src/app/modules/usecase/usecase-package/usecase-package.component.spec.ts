import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsecasePackageComponent } from './usecase-package.component';

describe('UsecasePackageComponent', () => {
  let component: UsecasePackageComponent;
  let fixture: UsecasePackageComponent;
  
    const useCases  = [
      {
        slNo: 1,
        useCaseId:"Use Case 00A",
        deployed: true,
        status: "Deployed",
        ticketCount: 100,
        moduleId: "Module 001",
        uploadedDate: "12 Dec 2020, 12:30",
        jobId: "Job ID 1000"
      },
      {
        slNo: 2,
        useCaseId:"Use Case 00B",
        deployed: false,
        status: "Not Deployed",
        ticketCount: 200,
        moduleId: "Module 001",
        uploadedDate: "12 Dec 2020, 12:30",
        jobId: "Job ID 1001"
      },
      {
        slNo: 3,
        useCaseId:"Use Case 00C",
        deployed: true,
        status: "Deployed",
        ticketCount: 300,
        moduleId: "Module 001",
        uploadedDate: "12 Dec 2020, 12:30",
        jobId: "Job ID 1002"
      },
      {
        slNo: 4,
        useCaseId:"Use Case 00D",
        deployed: true,
        status: "Deployed",
        ticketCount: 150,
        moduleId: "Module 001",
        uploadedDate: "12 Dec 2020, 12:30",
        jobId: "Job ID 1003"
      },
    ];
  
    
    beforeEach(() => {
      fixture = new UsecasePackageComponent();
      fixture.useCases = useCases;
      fixture.ngOnInit();
    });
    
    describe('Test: saveData', () => {
      it('should save treshold data saveData', () => {
        fixture.deleteUseCase();
      })
    })

    describe('Test: rowClickedEvent', () => {
      it('should call rowClickedEvent', () => {
        fixture.rowClickedEvent(useCases[0], null);
      })
    })

    describe('Test: showUpload', () => {
      it('should show upload card section on showUpload call', () => {
        fixture.showUpload();
      })
    })

    describe('Test: closeInfoBar', () => {
      it('should hide the right card section on closeInfoBar', () => {
        fixture.closeInfoBar();
      })
    })
});
