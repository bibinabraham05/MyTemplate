import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PcdTypesComponent } from './pcd-types.component';

describe('PcdTypesComponent', () => {
  let component: PcdTypesComponent;
  let fixture: ComponentFixture<PcdTypesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PcdTypesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PcdTypesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
