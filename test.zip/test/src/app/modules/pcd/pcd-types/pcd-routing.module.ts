import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { PcdTypesComponent } from './pcd-types.component';

const routes: Routes = [
  {
    path: '',
    component: PcdTypesComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PcdRoutingModule { }
