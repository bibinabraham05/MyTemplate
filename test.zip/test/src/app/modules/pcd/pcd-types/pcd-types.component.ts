import { trigger, transition, style, animate } from '@angular/animations';
import {Component, OnInit, ViewEncapsulation} from '@angular/core';
import {FormControl, FormGroup} from '@angular/forms';

import { FileUploadValidators } from '@iplab/ngx-file-upload';
import { pcds } from 'src/app/shared/models/pcds';
@Component({
  selector: 'app-pcd-types',
  templateUrl: './pcd-types.component.html',
  styleUrls: ['./pcd-types.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class PcdTypesComponent implements OnInit {

  showUploadCard: boolean = false; // show upload card section flag
  showPCDDetails: boolean = false; // show details section flag
  cardTitle: string; // set card title for each card section
  selectedPCD: string; // selected pcd to show details
  pcds: pcds[] = [] // pcd list

  
  private filesControl = new FormControl(null, FileUploadValidators.filesLimit(2));
  public demoForm = new FormGroup({
    files: this.filesControl
  });

  constructor() { 
    this.pcds =[
      {
        pcd_name:"PCD 00A",
        origin:"Root",
        consumption: 55
      },
      {
        pcd_name:"PCD 00B",
        origin:"Root",
        consumption: 57
      },
      {
        pcd_name:"PCD 00C",
        origin:"Root",
        consumption: 35
      },
      {
        pcd_name:"PCD 00D",
        origin:"Root",
        consumption: 90
      },
    ]
  }

  ngOnInit() {
  }

  public toggleStatus() {
    this.filesControl.disabled ? this.filesControl.enable() : this.filesControl.disable();
  }

  // show upload card section
  showUpload(){
    this.showUploadCard = true;
    this.cardTitle = 'Add PCD'
  }
  
  // select each pcd to show details
  rowClickedEvent(pcd:any,event:any){
    this.showPCDDetails = true;
    this.showUploadCard = false;
    this.cardTitle = pcd.pcd_name
    this.selectedPCD = pcd;
  }
  
  // close each card section
  closeInfoBar(){
    this.showUploadCard = false;
    this.showPCDDetails = false;
  }

}
