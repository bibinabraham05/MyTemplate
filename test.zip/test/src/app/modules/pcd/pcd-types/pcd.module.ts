import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {SharedModule} from '../../../shared/shared.module';
import {DataTablesModule} from 'angular-datatables';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { FileUploadModule } from '@iplab/ngx-file-upload';
import { PcdRoutingModule } from './pcd-routing.module';
import { NgbProgressbarModule } from '@ng-bootstrap/ng-bootstrap';
import { PcdTypesComponent } from './pcd-types.component';
import { FilesUploadModule } from '../../../shared/components/files-upload/files-upload.module';
import { PcdDetailsComponent } from '../pcd-details/pcd-details.component';



@NgModule({
  declarations: [PcdTypesComponent,PcdDetailsComponent],
  imports: [
    CommonModule,
    SharedModule,
    DataTablesModule,
    ReactiveFormsModule,
    FormsModule,
    FileUploadModule,
    PcdRoutingModule,
    NgbProgressbarModule,
    FilesUploadModule
  ]
})
export class PcdModule { }
