import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-pcd-details',
  templateUrl: './pcd-details.component.html',
  styleUrls: ['./pcd-details.component.scss']
})
export class PcdDetailsComponent implements OnInit {
  @Input() selectedPCD: any;
  @Input() cardTitle: string;
  @Output() closeDetailsEvent = new EventEmitter<boolean>();

  constructor() { }

  ngOnInit(): void {
    console.log("Selected PCD",this.selectedPCD)
  }

  closeInfoBar(){
    this.closeDetailsEvent.emit(true);
  }
}
