import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PcdDetailsComponent } from './pcd-details.component';

describe('PcdDetailsComponent', () => {
  let component: PcdDetailsComponent;
  let fixture: ComponentFixture<PcdDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PcdDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PcdDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
