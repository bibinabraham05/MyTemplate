import {Injectable} from '@angular/core';

export interface NavigationItem {
  id: string;
  title: string;
  type: 'item' | 'collapse' | 'group';
  translate?: string;
  icon?: string;
  hidden?: boolean;
  url?: string;
  classes?: string;
  exactMatch?: boolean;
  external?: boolean;
  target?: boolean;
  breadcrumbs?: boolean;
  function?: any;
  badge?: {
    title?: string;
    type?: string;
  };
  children?: Navigation[];
}

export interface Navigation extends NavigationItem {
  children?: NavigationItem[];
}

const NavigationItems = [
  {
    id: 'navigation',
    title: 'Navigation',
    type: 'group',
    icon: 'feather icon-align-left',
    children: [
      {
      id: 'dashboard',
      title: 'Dashboard',
      type: 'item',
      classes: 'nav-item',
      icon: 'feather icon-home',
      url: '/home/dashboard'
      },
      {
        id: 'inventory',
        title: 'Inventory',
        type: 'collapse',
        icon: 'feather icon-menu',
        children: [
          {
            id: 'usecase',
            title: 'Usecase',
            type: 'item',
            classes: 'nav-item',
            icon: 'feather icon-server',
            url: '/home/usecase'
          },
          {
            id: 'pcds',
            title: 'PCDs',
            type: 'item',
            classes: 'nav-item',
            icon: 'feather icon-layers',
            url: '/home/pcds'
          },
          {
            id: 'jobs',
            title: 'Jobs',
            type: 'item',
            classes: 'nav-item',
            icon: 'feather icon-package',
            url: '/home/jobs'
          }
        ]
      },
      {
        id: 'infra',
        title: 'Infra',
        type: 'collapse',
        icon: 'far fa-building',
        children: [
          {
            id: 'cluster',
            title: 'Cluster',
            type: 'item',
            classes: 'nav-item',
            icon: 'feather icon-server',
            url: '/home/cluster'
          },
          {
            id: 'appliances',
            title: 'Appliances',
            type: 'item',
            classes: 'nav-item',
            icon: 'feather icon-box',
            url: '/home/appliances'
          },
        ]
      },
      
      {
        id: 'Users',
        title: 'Users',
        type: 'item',
        classes: 'nav-item',
        icon: 'feather icon-users',
        url: '/home/user-list'
      },
      {
        id: 'task',
        title: 'Task',
        type: 'item',
        classes: 'nav-item',
        icon: 'feather icon-clipboard',
        url: '/home/task'
      },
      {
        id: 'Alerts',
        title: 'Alerts',
        type: 'item',
        classes: 'nav-item',
        icon: 'feather icon-alert-circle',
        url: '/home/alerts'
      }
    ]
  }
];

@Injectable()
export class NavigationItem {
  public get() {
    return NavigationItems;
  }
}
