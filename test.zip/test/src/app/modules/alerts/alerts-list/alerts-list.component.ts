import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { FileUploadValidators } from '@iplab/ngx-file-upload';
import { Alerts } from 'src/app/shared/models/alerts';

@Component({
  selector: 'app-alerts-list',
  templateUrl: './alerts-list.component.html',
  styleUrls: ['./alerts-list.component.css']
})
export class AlertsListComponent implements OnInit {

  // showUploadCard: boolean = false; // show upload card section
  showApplianceDetails: boolean = false; // show details card section
  closeButton: boolean = false; // to closed the card section that has been selected
  showResumeButton: boolean = true; // Toggle Resume and Pause button flag
  cardTitle: string = 'Recent Alerts'; 
  selectedAlert: any; // Selected Appliance to show the details
  alerts: Alerts[] = [] // Appliance List
  dtOptions: any = { }; // datatables options

  
  private filesControl = new FormControl(null, FileUploadValidators.filesLimit(2));
  public demoForm = new FormGroup({
    files: this.filesControl
  });

  constructor(private router: Router) { 
    this.dtOptions = { 
      pageLength:10,
      lengthChange: false,
      order:[[1,'asc']],
      columnDefs: [{orderable: false,targets: [0]}]
      }
      
    this.alerts =[
      {
        alert:"Alert 1",
        risk:"High",
        cluster_id:"ClusterID1",
        updated_on:"12 dec 2020, 9:30",
        source: "Appliance",
        generated_on: "12 Dec 2020, 10:30",
        status:"Activated"
      },
      {
        alert:"Alert 2",
        risk:"Low",
        cluster_id:"ClusterID2",
        updated_on:"12 dec 2020, 9:30",
        source: "Appliance",
        generated_on: "12 Dec 2020, 10:30",
        status:"Scheduled"
      },
      {
        alert:"Alert 3",
        risk:"High",
        cluster_id:"ClusterID3",
        updated_on:"12 dec 2020, 9:30",
        source: "Appliance",
        generated_on: "12 Dec 2020, 10:30",
        status:"Suspended"
      },
      {
        alert:"Alert 4",
        risk:"High",
        cluster_id:"ClusterID4",
        updated_on:"12 dec 2020, 9:30",
        source: "Appliance",
        generated_on: "12 Dec 2020, 10:30",
        status:"Decommisioned"
      },
      {
        alert:"Alert 5",
        risk:"Low",
        cluster_id:"ClusterID5",
        updated_on:"12 dec 2020, 9:30",
        source: "Appliance",
        generated_on: "12 Dec 2020, 10:30",
        status:"Suspended"
      }
    ]
  }

  ngOnInit() {
  }

  public toggleStatus() {
    this.filesControl.disabled ? this.filesControl.enable() : this.filesControl.disable();
  }

  // To activate all the Pending Activations
  activateAll(){
    console.log("activate all button clicked!")
  }

  // To show upload card section
  uploadAppliance(){
    // this.showUploadCard = true;
    // this.closeButton = true;
    // this.cardTitle = 'Add PCD'
  }
  
  // Select the appliance to show the details for
  rowClickedEvent(appliance:any,event:any){
    this.cardTitle = appliance.alert;
    this.selectedAlert = appliance;
    this.showApplianceDetails = true;
    this.closeButton = true;
  }

  // Resume each appliance
  resumeAppliance(appliance:any,event:any,index:any){
    console.log("appppp",appliance)
    this.alerts[index]['status'] = 'Activated'
    event.stopPropagation();
    this.showResumeButton = false;
  }
  
  // to close each card section
  closeInfoBar(){
    this.showApplianceDetails = false;
    // this.showUploadCard = false;
    this.closeButton = false;
  }
  navigateToThreshold(){
    // alert("navigated");
    // this.router.navigate(['/threshold']);
    // this.router.navigate(['./dashboard']);

  }

}
