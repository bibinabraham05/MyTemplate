import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { AlertsListComponent } from './alerts-list/alerts-list.component';
import { ThresholdComponent } from './threshold/threshold.component';

const routes: Routes = [
  {
    path: '',
    component: AlertsListComponent
  },
  {
    path: 'threshold',
    component: ThresholdComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AlertsRoutingModule { }