import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ApexChartService } from 'src/app/shared/components/chart/apex-chart/apex-chart.service';

@Component({
  selector: 'app-alert-details',
  templateUrl: './alert-details.component.html',
  styleUrls: ['./alert-details.component.css']
})
export class AlertDetailsComponent implements OnInit {

  @Input() selectedAlert: any;
  @Input() cardTitle: string;
  @Output() closeDetailsEvent = new EventEmitter<boolean>();
  area1CAC: any = { };
  // appliance_name: any;

  constructor(public apexEvent: ApexChartService) {
  }

  ngOnInit(): void {
    console.log("Selected Alert",this.selectedAlert)
  }

  closeInfoBar(){
    this.closeDetailsEvent.emit(true);
  }

}
