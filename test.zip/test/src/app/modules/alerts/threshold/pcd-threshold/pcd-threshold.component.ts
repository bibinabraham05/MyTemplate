import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pcd-threshold',
  templateUrl: './pcd-threshold.component.html',
  styleUrls: ['./pcd-threshold.component.css']
})
export class PcdThresholdComponent implements OnInit {

  public thresholdValues:Object = [
    {
      "name": "CPU",
      "warning": Number,
      "critical": Number 
    },
    {
      "name": "Memory",
      "warning": Number,
      "critical": Number 
    },
    {
      "name": "Disk",
      "warning": Number,
      "critical": Number 
    },
    {
      "name": "Transaction",
      "warning": Number,
      "critical": Number 
    },
    {
      "name": "Success Rate",
      "warning": Number,
      "critical": Number 
    } 
  ];
  
  constructor() { }

  ngOnInit(): void {
  }

  /* To set pcd threshold data */
  saveThresholdData(): void{

  }

}
