import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PcdThresholdComponent } from './pcd-threshold.component';

describe('PcdThresholdComponent', () => {
  let component: PcdThresholdComponent;
  let fixture: PcdThresholdComponent;
  const thresholdValues =
  [
    {
      "name": "CPU",
      "warning": Number,
      "critical": Number 
    },
    {
      "name": "Memory",
      "warning": Number,
      "critical": Number 
    },
    {
      "name": "Disk",
      "warning": Number,
      "critical": Number 
    },
    {
      "name": "Transaction",
      "warning": Number,
      "critical": Number 
    },
    {
      "name": "Success Rate",
      "warning": Number,
      "critical": Number 
    } 
  ];

  
  beforeEach(() => {
    fixture = new PcdThresholdComponent();
    fixture.thresholdValues = thresholdValues;
    fixture.ngOnInit();
  });

  describe('Test: saveData', () => {
    it('should save treshold data saveData', () => {
      fixture.saveThresholdData();
    })
  })

});
