import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ThresholdComponent } from './threshold.component';

describe('ThresholdComponent', () => {
  let component: ThresholdComponent;
  let fixture: ThresholdComponent;

  const thresholdValues = [
    {
      "CPU" : {
        "warning": {"max":20, "min":0},
        "critical": {"max":100, "min":50}
      }
    }
  ];

  
  beforeEach(() => {
    fixture = new ThresholdComponent();
    fixture.thresholdValues = thresholdValues;
    fixture.ngOnInit();
  });
  
  describe('Test: saveData', () => {
    it('should save treshold data saveData', () => {
      fixture.saveThresholdData();
    })
  })
});
