import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appliance-threshold',
  templateUrl: './appliance-threshold.component.html',
  styleUrls: ['./appliance-threshold.component.css']
})
export class ApplianceThresholdComponent implements OnInit {

  public thresholds: Object = {
    "applianceID": "appliance ID",
    "cpu": {
      "warning": 50,
      "critical": 80
    },
    "memory": {
      "warning": 50,
      "critical": 80
    },
    "disk": {
      "warning": 50,
      "critical": 80
    },
    "transaction": {
      "warning": 50,
      "critical": 80
    },
    "successrate": {
      "warning": 50,
      "critical": 80
    }
  }
  thresholdValues:any = [
    {
      "name": "CPU",
      "warning": Number,
      "critical": Number 
    },
    {
      "name": "Memory",
      "warning": Number,
      "critical": Number 
    },
    {
      "name": "Disk",
      "warning": Number,
      "critical": Number 
    },
    {
      "name": "Transaction",
      "warning": Number,
      "critical": Number 
    },
    {
      "name": "Success Rate",
      "warning": Number,
      "critical": Number 
    } 
  ];

  constructor() { }

  ngOnInit(): void {
  }
 /* To set Appliance threshold data */
  saveThresholdData(): void{

  }
}
