import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplianceThresholdComponent } from './appliance-threshold.component';

describe('ApplianceThresholdComponent', () => {
  let component: ApplianceThresholdComponent;
  let fixture: ApplianceThresholdComponent;

  const thresholdValues =
  [
    {
      "name": "CPU",
      "warning": Number,
      "critical": Number 
    },
    {
      "name": "Memory",
      "warning": Number,
      "critical": Number 
    },
    {
      "name": "Disk",
      "warning": Number,
      "critical": Number 
    },
    {
      "name": "Transaction",
      "warning": Number,
      "critical": Number 
    },
    {
      "name": "Success Rate",
      "warning": Number,
      "critical": Number 
    } 
  ];

  
  beforeEach(() => {
    fixture = new ApplianceThresholdComponent();
    fixture.thresholdValues = thresholdValues;
    fixture.ngOnInit();
  });
  
  describe('Test: saveData', () => {
    it('should save treshold data saveData', () => {
      fixture.saveThresholdData();
    })
  })
});
