import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CmccThresholdComponent } from './cmcc-threshold.component';

describe('CmccThresholdComponent', () => {
  let component: CmccThresholdComponent;
  let fixture: CmccThresholdComponent;

  const thresholdValues =
  [
    {
      "name": "CPU",
      "warning": Number,
      "critical": Number 
    },
    {
      "name": "Memory",
      "warning": Number,
      "critical": Number 
    },
    {
      "name": "Disk",
      "warning": Number,
      "critical": Number 
    },
    {
      "name": "Transaction",
      "warning": Number,
      "critical": Number 
    },
    {
      "name": "Success Rate",
      "warning": Number,
      "critical": Number 
    } 
  ];

  
  beforeEach(() => {
    fixture = new CmccThresholdComponent();
    fixture.thresholdValues = thresholdValues;
    fixture.ngOnInit();
  });
  
  describe('Test: saveData', () => {
    it('should save treshold data saveData', () => {
      fixture.saveThresholdData();
    })
  })
});
