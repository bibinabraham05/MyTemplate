import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cmcc-threshold',
  templateUrl: './cmcc-threshold.component.html',
  styleUrls: ['./cmcc-threshold.component.css']
})
export class CmccThresholdComponent implements OnInit {

  public thresholdValues:Object[] = [
    {
      "name": "CPU",
      "warning": Number,
      "critical": Number 
    },
    {
      "name": "Memory",
      "warning": Number,
      "critical": Number 
    },
    {
      "name": "Disk",
      "warning": Number,
      "critical": Number 
    },
    {
      "name": "Transaction",
      "warning": Number,
      "critical": Number 
    },
    {
      "name": "Success Rate",
      "warning": Number,
      "critical": Number 
    } 
  ];

  constructor() { }

  ngOnInit(): void {
  }
/* To set CMCC threshold data */
  saveThresholdData(): void{

  }

}
