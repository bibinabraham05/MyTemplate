import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-threshold',
  templateUrl: './threshold.component.html',
  styleUrls: ['./threshold.component.css']
})
export class ThresholdComponent implements OnInit {

  thresholdValues:Object[] = [
    {
      "CPU" : {
        "warning": {"max":20, "min":0},
        "critical": {"max":100, "min":50}
      }
    }
  ];
  constructor() { }

  ngOnInit(): void {
  }

  /* To set threshold data */
  saveThresholdData(): void{

  }

}
