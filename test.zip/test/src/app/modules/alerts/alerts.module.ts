import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AlertsListComponent } from './alerts-list/alerts-list.component';
import { AlertDetailsComponent } from './alert-details/alert-details.component';

import { DataTablesModule } from 'angular-datatables';
import { SharedModule } from './../../shared/shared.module';
import { FilesUploadModule } from './../../shared/components/files-upload/files-upload.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AlertsRoutingModule } from './alerts-routing.module';
import { ThresholdComponent } from './threshold/threshold.component';
import { PcdThresholdComponent } from './threshold/pcd-threshold/pcd-threshold.component';
import { CmccThresholdComponent } from './threshold/cmcc-threshold/cmcc-threshold.component';
import { ApplianceThresholdComponent } from './threshold/appliance-threshold/appliance-threshold.component';



@NgModule({
  declarations: [AlertsListComponent, AlertDetailsComponent, ThresholdComponent, PcdThresholdComponent, CmccThresholdComponent, ApplianceThresholdComponent],
  imports: [
    CommonModule,
    SharedModule,
    DataTablesModule,
    AlertsRoutingModule,
    FilesUploadModule,
    NgbModule
  ]
})
export class AlertsModule { }
