import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AppConfigService {

  // private apiUrl: string = environment.apiUrl;
  fetchUsersListUrl: string;
  fetchClusterUrl: string;

  constructor() {
    this.fetchUsersListUrl = '/api/users';
    this.fetchClusterUrl='/api/cminfra/appliancecluster'
  }
getClusterUrl(){
  return this.fetchClusterUrl;
}
  getUsersListUrl(): string {
    return this.fetchUsersListUrl;
  }
}
