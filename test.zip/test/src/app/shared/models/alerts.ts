export interface Alerts {
    alert: string;
    risk: string,
    cluster_id: string,
    updated_on: string,
    source: string,
    generated_on: string,
    status: string
}