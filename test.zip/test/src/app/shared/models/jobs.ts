export  interface Jobs {
    job_name: string,
    cluster_id: string,    
    usecase: string,
    ticket_count: string,
    updated_ticket_count: string,
    consumed: string
}