export interface appliances {
    appliance_name: string,
    cluster_id: string,
    updated_on: string,
    location: string,
    deployed_usecases: any,
    status: string
}