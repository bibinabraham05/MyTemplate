export interface pcds{
    pcd_name: string,
    origin: string,
    consumption: number
}