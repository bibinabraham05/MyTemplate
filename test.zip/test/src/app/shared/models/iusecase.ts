export interface IUseCase {
      slNo: number,
      useCaseId: string,
      deployed: boolean,
      status: string,
      ticketCount: number,
      moduleId: string,
      uploadedDate: string;
      jobId: string;
}