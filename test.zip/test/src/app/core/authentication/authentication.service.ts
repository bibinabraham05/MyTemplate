import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, map, tap } from 'rxjs/operators';
import { Http2SecureServer } from 'http2';
import { environment } from 'src/environments/environment';
const LOGIN_URL=environment.auth_url;//variable which contains the value of the authentication url
@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  private access_token:any;
  private refresh_token:any;
  constructor(private http:HttpClient) { }
  /*
  Login method which makes api calls to login api and recieves token response
  */
  login(data:any){
  return this.http.get<any>(LOGIN_URL,data)
    .pipe(
      map(data =>{return data; })
    );
    }
}
