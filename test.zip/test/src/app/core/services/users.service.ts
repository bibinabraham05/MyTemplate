import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AppConfigService } from '../../shared/services/app-config.service';
import { IUser } from '../../shared/models/iuser';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  constructor(private app_config: AppConfigService, private http: HttpClient) { }

  public getUsersList(): Observable<IUser[]> {
    const url = this.app_config.getUsersListUrl();
    const response = this.http.get<IUser[]>(url);
    return response;
  }
}
