import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule, routingComponents } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// PrimeNG Modules imports
import {ButtonModule} from 'primeng/button';
import {InputTextModule} from 'primeng/inputtext';
import { LoginComponent } from './modules/authentication/login/login.component';
import { ForgotPasswordComponent } from './modules/authentication/forgot-password/forgot-password.component';
import { ToggleFullScreenDirective } from './shared/full-screen/toggle-full-screen';
import {  NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SharedModule } from './shared/shared.module';
import { AdminComponent } from './modules/theme/layout/admin/admin.component';
import { NavigationComponent } from './modules/theme/layout/admin/navigation/navigation.component';
import { NavContentComponent } from './modules/theme/layout/admin/navigation/nav-content/nav-content.component';
import { NavGroupComponent } from './modules/theme/layout/admin/navigation/nav-content/nav-group/nav-group.component';
import { NavCollapseComponent } from './modules/theme/layout/admin/navigation/nav-content/nav-collapse/nav-collapse.component';
import { NavItemComponent } from './modules/theme/layout/admin/navigation/nav-content/nav-item/nav-item.component';
import { NavBarComponent } from './modules/theme/layout/admin/nav-bar/nav-bar.component';
import { NavLeftComponent } from './modules/theme/layout/admin/nav-bar/nav-left/nav-left.component';
import { NavSearchComponent } from './modules/theme/layout/admin/nav-bar/nav-left/nav-search/nav-search.component';
import { NavRightComponent } from './modules/theme/layout/admin/nav-bar/nav-right/nav-right.component';
import { ConfigurationComponent } from './modules/theme/layout/admin/configuration/configuration.component';
import { NavigationItem } from './modules/theme/layout/admin/navigation/navigation';
import { HttpClientModule } from '@angular/common/http';
import { AddUserComponent } from './modules/users/users-list/add-user/add-user.component';
import { EditUserComponent } from './modules/users/users-list/edit-user/edit-user.component';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ForgotPasswordComponent,
    routingComponents,
    AdminComponent,
    NavigationComponent,
    NavContentComponent,
    NavGroupComponent,
    NavCollapseComponent,
    NavItemComponent,
    NavBarComponent,
    NavLeftComponent,
    NavSearchComponent,
    NavRightComponent,
    ConfigurationComponent,
    ToggleFullScreenDirective,
    AddUserComponent,
    EditUserComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    ButtonModule,
    SharedModule,
    InputTextModule,
    NgbModule,
    BrowserAnimationsModule,
    HttpClientModule
  ],
  providers: [NavigationItem],
  entryComponents:[
    AddUserComponent,
    EditUserComponent
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
