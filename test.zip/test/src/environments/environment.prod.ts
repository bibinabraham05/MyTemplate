export const environment = {
  production: true,
  authUrl:'',
  apiUrl:''
};
